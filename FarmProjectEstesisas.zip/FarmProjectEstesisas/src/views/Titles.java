package views;

public class Titles {

	public static final int ID=0;
	public static final int LASTHEATORSICKS=1;
	public static final int INSDATEORMEDS=2;
	public static final int DUEDATEORSTATE=3;
	public static final int NEXTDUE=4;
	
	public static int filaSeleccionada;
	
	
	
	
}