package models;

public enum CowState {
    MILKMAID, DRYING, INSEMINATED,CONFIRMED,SIN;
}
