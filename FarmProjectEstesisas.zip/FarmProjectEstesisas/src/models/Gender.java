package models;

public enum Gender {
    FEMALE, MALE
}
