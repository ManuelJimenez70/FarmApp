package runner;

import controller.Controller;

/**@author Manuel Jimenez
 * @author Tania Catalina
 */
public class Run {

	public static void main(String[] args) {
		Controller c = new Controller();
	}
}
